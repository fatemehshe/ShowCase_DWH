USE [Mytest_db]
GO

IF NOT EXISTS (SELECT * FROM SYS.schemas WHERE SCHEMA_ID=SCHEMA_ID('SVM'))
BEGIN
EXEC sp_executesql N'CREATE SCHEMA [SVM] AUTHORIZATION [public]'  ;

END
GO

--------------------------------------------
IF NOT EXISTS(SELECT * FROM SYS.tables WHERE object_id=object_id('SVM.Dim_Location'))
BEGIN

CREATE TABLE [svm].[Dim_Location](
	[LocationId] [bigint] NOT NULL IDENTITY(1,1) ,
	[LocationName] [varchar](300) NOT NULL,
	[LocationShortName] [varchar](20) NOT NULL,
	[IsActive] [bit] NOT NULL,
	[ModifiedDateTime] [datetime] NOT NULL,
	[ModifiedUserName] [varchar](100) NOT NULL,
 CONSTRAINT [PK_Dim_Location] PRIMARY KEY CLUSTERED 
(
	[LocationId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


ALTER TABLE [svm].[Dim_Location] ADD  CONSTRAINT [DF_Dim_Location_ModifiedDateTime]  DEFAULT (getdate()) FOR [ModifiedDateTime]


ALTER TABLE [svm].[Dim_Location] ADD  CONSTRAINT [DF_Dim_Location_ModifiedUserName]  DEFAULT (user_name()) FOR [ModifiedUserName]


EXEC sys.sp_addextendedproperty @name=N'LocationId', @value=N'Unique Location surrogate key' , @level0type=N'SCHEMA',@level0name=N'svm', @level1type=N'TABLE',@level1name=N'Dim_Location', @level2type=N'COLUMN',@level2name=N'LocationId'


EXEC sys.sp_addextendedproperty @name=N'Dim_Location', @value=N'A type 1 dimension to store locations' , @level0type=N'SCHEMA',@level0name=N'svm', @level1type=N'TABLE',@level1name=N'Dim_Location'

END
GO


----------------------------------------------------

IF NOT EXISTS(SELECT * FROM SYS.tables WHERE object_id=object_id('SVM.Dim_Customer'))
BEGIN

CREATE TABLE [svm].[Dim_Customer](
	[CustomerId] [bigint] NOT NULL IDENTITY(1,1) ,
	[CustomerName] [varchar](300) NOT NULL,
	[EffectiveDateFrom] [datetime] NOT NULL,
	[EffectiveDateTo] [datetime] NULL,
	[IsActive] [bit] NOT NULL,
	[CustomerLocationId] [bigint] NOT NULL,
	[ModfiedDateTime] [datetime] NOT NULL,
	[ModifiedUser] [varchar](200) NOT NULL,
 CONSTRAINT [PK_Dim_Customer] PRIMARY KEY CLUSTERED 
(
	[CustomerId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


ALTER TABLE [svm].[Dim_Customer] ADD  CONSTRAINT [DF_Dim_Customer_ModfiedDateTime]  DEFAULT (getdate()) FOR [ModfiedDateTime]


ALTER TABLE [svm].[Dim_Customer] ADD  CONSTRAINT [DF_Dim_Customer_ModifiedUser]  DEFAULT (user_name()) FOR [ModifiedUser]


ALTER TABLE [svm].[Dim_Customer]  WITH CHECK ADD  CONSTRAINT [FK_Dim_Customer_Dim_Location] FOREIGN KEY([CustomerLocationId])
REFERENCES [svm].[Dim_Location] ([LocationId])


ALTER TABLE [svm].[Dim_Customer] CHECK CONSTRAINT [FK_Dim_Customer_Dim_Location]


EXEC sys.sp_addextendedproperty @name=N'CustomerId', @value=N'unique customer surrogate key' , @level0type=N'SCHEMA',@level0name=N'svm', @level1type=N'TABLE',@level1name=N'Dim_Customer', @level2type=N'COLUMN',@level2name=N'CustomerId'


EXEC sys.sp_addextendedproperty @name=N'EffectiveDateTo', @value=N'a date to show when the record expires' , @level0type=N'SCHEMA',@level0name=N'svm', @level1type=N'TABLE',@level1name=N'Dim_Customer', @level2type=N'COLUMN',@level2name=N'EffectiveDateTo'


EXEC sys.sp_addextendedproperty @name=N'CustomerLocationId', @value=N'Foreign key to Location Dimension' , @level0type=N'SCHEMA',@level0name=N'svm', @level1type=N'TABLE',@level1name=N'Dim_Customer', @level2type=N'COLUMN',@level2name=N'CustomerLocationId'


EXEC sys.sp_addextendedproperty @name=N'Dim_Customer', @value=N'a type 2 dimension table to keep customer information' , @level0type=N'SCHEMA',@level0name=N'svm', @level1type=N'TABLE',@level1name=N'Dim_Customer'


END

--------------------------------------------------------

IF NOT EXISTS(SELECT * FROM SYS.tables WHERE object_id=object_id('SVM.Dim_Currency'))
BEGIN

CREATE TABLE [svm].[Dim_Currency](
	[CurrencyId] [bigint] NOT NULL IDENTITY(1,1),
	[CurrencyCode] [varchar](10) NOT NULL,
	[CurrencyRate] [numeric](10, 2) NOT NULL,
	[ModifiedDateTime] [datetime] NOT NULL,
	[ModifiedUser] [varchar](200) NOT NULL,
 CONSTRAINT [PK_Dim_Currency] PRIMARY KEY CLUSTERED 
(
	[CurrencyId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


ALTER TABLE [svm].[Dim_Currency] ADD  CONSTRAINT [DF_Dim_Currency_ModifiedDateTime]  DEFAULT (getdate()) FOR [ModifiedDateTime]


ALTER TABLE [svm].[Dim_Currency] ADD  CONSTRAINT [DF_Dim_Currency_ModifiedUser]  DEFAULT (user_name()) FOR [ModifiedUser]


EXEC sys.sp_addextendedproperty @name=N'Dim_Currency', @value=N'A type 1 dimension to store currencies and their rates' , @level0type=N'SCHEMA',@level0name=N'svm', @level1type=N'TABLE',@level1name=N'Dim_Currency'


END

GO

-------------------------------------------------


IF NOT EXISTS(SELECT * FROM SYS.tables WHERE object_id=object_id('SVM.Dim_Product'))
BEGIN

CREATE TABLE [svm].[Dim_Product](
	[ProductId] [bigint] NOT NULL IDENTITY(1,1) ,
	[ProductName] [varchar](200) NOT NULL,
	[ProductCurrencyId] [bigint] NOT NULL,
	[ProductValue] [numeric](10, 2) NOT NULL,
	[ProductDescription] [varchar](1000) NULL,
	[EffectiveDateFrom] [datetime] NOT NULL,
	[EffectiveDateTo] [datetime] NULL,
	[IsActive] [bit] NOT NULL,
	[ModifiedDateTIme] [datetime] NOT NULL,
	[ModifiedUser] [varchar](200) NOT NULL,
 CONSTRAINT [PK_Dim_Product] PRIMARY KEY CLUSTERED 
(
	[ProductId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


ALTER TABLE [svm].[Dim_Product] ADD  CONSTRAINT [DF_Dim_Product_ModifiedDateTIme]  DEFAULT (getdate()) FOR [ModifiedDateTIme]


ALTER TABLE [svm].[Dim_Product] ADD  CONSTRAINT [DF_Dim_Product_ModifiedUser]  DEFAULT (user_name()) FOR [ModifiedUser]

ALTER TABLE [svm].[Dim_Product]  WITH CHECK ADD  CONSTRAINT [FK_Dim_Product_Dim_Currency] FOREIGN KEY([ProductCurrencyId])
REFERENCES [svm].[Dim_Currency] ([CurrencyId])

EXEC sys.sp_addextendedproperty @name=N'ProductCurrenyId', @value=N'A foreign key to currency table' , @level0type=N'SCHEMA',@level0name=N'svm', @level1type=N'TABLE',@level1name=N'Dim_Product', @level2type=N'COLUMN',@level2name=N'ProductCurrencyId'


EXEC sys.sp_addextendedproperty @name=N'Dim_Product', @value=N'A Type 2 dimension to store product information' , @level0type=N'SCHEMA',@level0name=N'svm', @level1type=N'TABLE',@level1name=N'Dim_Product'



END



------------------------------------------------------------------

IF NOT EXISTS(SELECT * FROM SYS.tables WHERE object_id=object_id('SVM.Fact_Transactions'))
BEGIN

CREATE TABLE [svm].[Fact_Transactions](
	[TransactionId] [bigint] NOT NULL IDENTITY(1,1) ,
	[TransactionCode] [varchar](100) NOT NULL,
	[TransactionInsertDate] [datetime] NOT NULL,
	[TransactionEffectiveDate] [datetime] NOT NULL,
	[TransactionCustomerId] [bigint] NOT NULL,
	[TransactionProductId] [bigint] NOT NULL,
	[BasicNetPrice] [numeric](18, 2)  NULL,
	[BasicGrossPrice] [numeric](18, 2)  NULL,
	[NativeNetPrice] [numeric](18, 2)  NULL,
	[NativeGrossPrice] [numeric](18, 2)  NULL,
	[ModifiedDateTime] [datetime] NOT NULL,
	[ModifiedUser] [varchar](200) NOT NULL,
 CONSTRAINT [PK_Fact_Transactions] PRIMARY KEY CLUSTERED 
(
	[TransactionId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


ALTER TABLE [svm].[Fact_Transactions] ADD  CONSTRAINT [DF_Fact_Transactions_ModifiedDateTime]  DEFAULT (getdate()) FOR [ModifiedDateTime]


ALTER TABLE [svm].[Fact_Transactions] ADD  CONSTRAINT [DF_Fact_Transactions_ModifiedUser]  DEFAULT (user_name()) FOR [ModifiedUser]


ALTER TABLE [svm].[Fact_Transactions]  WITH CHECK ADD  CONSTRAINT [FK_Fact_Transactions_Dim_Customer] FOREIGN KEY([TransactionCustomerId])
REFERENCES [svm].[Dim_Customer] ([CustomerId])


ALTER TABLE [svm].[Fact_Transactions] CHECK CONSTRAINT [FK_Fact_Transactions_Dim_Customer]


ALTER TABLE [svm].[Fact_Transactions]  WITH CHECK ADD  CONSTRAINT [FK_Fact_Transactions_Dim_Product] FOREIGN KEY([TransactionProductId])
REFERENCES [svm].[Dim_Product] ([ProductId])


ALTER TABLE [svm].[Fact_Transactions] CHECK CONSTRAINT [FK_Fact_Transactions_Dim_Product]


EXEC sys.sp_addextendedproperty @name=N'Fact_Transactions', @value=N'A Fact tablestoring all the customer/product transaction histories' , @level0type=N'SCHEMA',@level0name=N'svm', @level1type=N'TABLE',@level1name=N'Fact_Transactions'


END

----------------------------------------------
IF  EXISTS(select * from sys.all_objects where object_id = object_id ('SVM.fn_SplitString') and type='TF')

drop function SVM.[fn_SplitString]
GO

CREATE FUNCTION SVM.fn_SplitString( @StringInput VARCHAR(MAX), @Delimiter nvarchar(1))
RETURNS @OutputTable TABLE ( [String] VARCHAR(10) )
AS
BEGIN

    DECLARE @String    VARCHAR(10)

    WHILE LEN(@StringInput) > 0
    BEGIN
        SET @String      = LEFT(@StringInput, 
                                ISNULL(NULLIF(CHARINDEX(@Delimiter, @StringInput) - 1, -1),
                                LEN(@StringInput)))
        SET @StringInput = SUBSTRING(@StringInput,
                                     ISNULL(NULLIF(CHARINDEX(@Delimiter, @StringInput), 0),
                                     LEN(@StringInput)) + 1, LEN(@StringInput))

        INSERT INTO @OutputTable ( [String] )
        VALUES ( @String )
    END

    RETURN
END
GO