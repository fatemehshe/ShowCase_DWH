USE [Mytest_db]
GO



--update transaction native prices based on basic prices and rates of the currency(it only keeps one rate), 
--native price = basic price * rate from product table


UPDATE SVM.Fact_Transactions 
    SET NativeGrossPrice= tr.BasicGrossPrice * cr.CurrencyRate ,
	    NativeNetPrice= tr.BasicNetPrice * cr.CurrencyRate
 FROM SVM.Fact_Transactions tr
	INNER JOIN SVM.Dim_Product pr
		ON tr.TransactionProductId = pr.ProductId
	INNER JOIN SVM.Dim_Currency cr
		ON pr.ProductCurrencyId = cr.CurrencyId

----------------------------------
--list all the transactions inserted as of '2020-01-01' and with active customer and active product name, currency and locations
--but they were not active yet (active transaction are the ones with insertdate and effectivedate before the report date)
--list only latest transactions (by transaction code)
--if native net price is greater than basic price it's group 'x1' else it's 'x2'
--for any transaction in group 'x1' and currency not 'USD' and effectivedate in Jan 2020 New Category should be 'Group' + last digitis of transaction code after "/"


;WITH Trans_CTE AS 
(
SELECT ROW_NUMBER() OVER(PARTITION BY tr.transactioncode order by tr.ModifiedDatetime desc) rn,tr.*
,cu.CustomerName,lo.LocationName,pr.ProductName,cr.CurrencyCode 

FROM SVM.Fact_Transactions tr
	INNER JOIN SVM.Dim_Product pr
		ON tr.TransactionProductId = pr.ProductId 
			AND pr.IsActive = 1
	INNER JOIN SVM.Dim_Currency cr
		ON pr.ProductCurrencyId = cr.CurrencyId
	INNER JOIN SVM.Dim_Customer cu
		ON tr.TransactionCustomerId = cu.CustomerId 
			AND cu.IsActive = 1
	INNER JOIN SVM.Dim_Location lo
		ON cu.CustomerLocationId = lo.LocationId

		WHERE tr.TransactionInsertDate <= '2020-01-01'
		AND   tr.TransactionEffectiveDate >'2020-01-01'
)

SELECT  TransGroup,
		CASE WHEN TransGroup ='X1' AND CurrencyCode<>'USD' AND 
			(TransactionEffectiveDate BETWEEN '2020-01-01' AND '2020-01-31')
			 THEN TransGroup + 
			 SUBSTRING(TransactionCode,len(TransactionCode)-charindex('/',reverse(TransactionCode))+2,len(TransactionCode)) END NewCategory
			 
			 ,* FROM 

		Trans_CTE 
		CROSS APPLY (SELECT CASE WHEN NativeNetPrice > BasicNetPrice THEN 'X1' ELSE 'X2' END TransGroup) AS TransGroup
WHERE rn = 1
------------------------------------------------------------------------------------
--get a list of customers in comma separated format and return the list of products for the ones with active transactions
GO

declare @string varchar(1000)= 'customer3,customer2,customer22'

IF OBJECT_ID('tempdb.dbo.#customer') IS NOT NULL
    DROP TABLE #customer


SELECT * into #customer 
	FROM SVM.Dim_Customer cu
		INNER JOIN SVM.fn_SplitString(@string,',') AS ls
			ON cu.CustomerName = ls.string
			 AND cu.IsActive = 1
			 AND EffectiveDateTo IS NULL

SELECT pr.ProductName FROM #customer cu
		INNER JOIN SVM.Fact_Transactions tr
			ON tr.TransactionCustomerId = cu.CustomerId
				 AND  tr.TransactionInsertDate <= GETDATE()
				 AND   tr.TransactionEffectiveDate <= GETDATE()
		INNER JOIN SVM.Dim_Product pr
			ON pr.ProductId = tr.TransactionProductId	

	GROUP BY pr.ProductName


------------------------------------------
--return all unique possible combination of customer and product and if the combination has a valid transaction record, return the country for it

;WITH CustomerProduct_CTE AS
(
SELECT  pr.ProductName,PR.Productid,cu.CustomerLocationId,CU.CustomerName,cu.CustomerId FROM SVM.Dim_Customer cu
		CROSS JOIN SVM.Dim_Product pr
),

trans_cte as
(select row_number() over(Partition by transactioncustomerid,transactionproductid order by modifieddatetime desc) tr_rn,* from svm.Fact_Transactions 
  				 WHERE  TransactionInsertDate <= GETDATE()
				 AND    TransactionEffectiveDate <= GETDATE())
,
trans_cus_prod_CTE AS
(
select pr_cu.ProductName,pr_cu.CustomerName,case when tr.TransactionId IS NOT NULL THEN CustomerLocationId ELSE NULL END CustomerLocationId
		
	from CustomerProduct_CTE pr_cu
		left outer join 
			(select tr.TransactionId, tr.TransactionCustomerId,tr.TransactionProductId from   trans_cte tr where tr.tr_rn = 1) tr
			on pr_cu.CustomerId = tr.TransactionCustomerId
			AND  pr_cu.ProductId = tr.TransactionProductId
)

select ProductName,CustomerName,lo.LocationName	 from
	trans_cus_prod_CTE
		left outer join svm.Dim_Location lo
			on trans_cus_prod_CTE.CustomerLocationId = lo.LocationId	
			
		GROUP BY ProductName,CustomerName,lo.LocationName		