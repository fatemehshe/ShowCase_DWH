USE [Mytest_db]
GO


truncate table [SVM].[Fact_Transactions]
go
delete from [SVM].[Dim_Customer]
go
delete from [SVM].[Dim_Product]
go
delete from [SVM].[Dim_Location]
go
delete from [SVM].[Dim_Currency]

SET IDENTITY_INSERT [SVM].[Dim_Currency] ON

insert into [SVM].[Dim_Currency] ( CurrencyId,CurrencyCode, CurrencyRate) values(1,'AUD',1),(2,'USD',0.7),(3,'GBP',0.8),(4,'ITL',1178.00)

SET IDENTITY_INSERT [SVM].[Dim_Currency] OFF
GO

SET IDENTITY_INSERT [SVM].[Dim_Location] ON

insert into [SVM].[Dim_Location] ( LocationId,LocationName, LocationShortName, IsActive) values (1,'Australia','AU',1),(2,'England','En',1),(3,'United States','US',1),(4,'Spain','ES',0)

SET IDENTITY_INSERT [SVM].[Dim_Location] OFF
GO

SET IDENTITY_INSERT [SVM].[Dim_Product] ON

insert into [SVM].[Dim_Product] (ProductId, ProductName, ProductCurrencyId, ProductValue, ProductDescription, EffectiveDateFrom, EffectiveDateTo, IsActive)
values (1,'Product1',1,200,'this is product 1','2010-07-25',null,1),
 (2,'Product2',2,1500,'this is product 2','2010-07-25','2020-02-25',1),
 (3,'Product2',2,157,'this is product 2','2020-02-25',null,1),
 (4,'Product3',3,70,'this is product 3','2010-07-25','2020-09-30',0),
 (5,'Product4',3,200,'this is product 4','2010-07-25','2019-08-30',1),
 (6,'Product4',4,170,'this is product 4','2019-08-30','2020-01-30',1),
 (7,'Product4',4,185.7,'this is product 4','2020-01-30',null,1)

 SET IDENTITY_INSERT [SVM].[Dim_Product] OFF

 GO

 SET IDENTITY_INSERT [SVM].[Dim_Customer] ON

 insert into [SVM].[Dim_Customer] (CustomerId, CustomerName, EffectiveDateFrom, EffectiveDateTo, IsActive, CustomerLocationId)
 values (1,'customer1','2012-02-21',null,1,1),
 (2,'customer2','2013-02-21','2019-10-04',1,2),
 (3,'customer22','2019-10-04',null,1,2),
  (4,'customer3','2019-10-04',null,0,3)

  SET IDENTITY_INSERT [SVM].[Dim_Customer] OFF
GO

  insert into [SVM].[Fact_Transactions] (TransactionCode, TransactionInsertDate, TransactionEffectiveDate, TransactionCustomerId, 
  TransactionProductId, BasicNetPrice, BasicGrossPrice, ModifiedDateTime)
   values('AAA/12/32',getdate()-120,getdate()-97,1,2,700,720,getdate()-2) ,
   ('AAA/14/34',getdate()-150,getdate()-149,1,3,800,810.25,getdate()-2) ,
   ('AAA/15/342',getdate()-120,getdate()-120,2,6,900,930.7,getdate()-2) ,
   ('AAA/17/35',getdate()-10,getdate()+5,3,1,300,340.5,getdate()-2) 

   insert into [SVM].[Fact_Transactions] (TransactionCode, TransactionInsertDate, TransactionEffectiveDate, TransactionCustomerId, 
  TransactionProductId, BasicNetPrice, BasicGrossPrice, ModifiedDateTime)
   select TransactionCode, TransactionInsertDate, TransactionEffectiveDate, TransactionCustomerId, 
  TransactionProductId, BasicNetPrice, BasicGrossPrice-1, ModifiedDateTime-1
  from [SVM].[Fact_Transactions] 



     insert into [SVM].[Fact_Transactions] (TransactionCode, TransactionInsertDate, TransactionEffectiveDate, TransactionCustomerId, 
  TransactionProductId, BasicNetPrice, BasicGrossPrice, ModifiedDateTime)
   select TransactionCode, TransactionInsertDate-160, TransactionEffectiveDate-40, TransactionCustomerId, 
  TransactionProductId, BasicNetPrice, BasicGrossPrice-1, ModifiedDateTime-1
  from [SVM].[Fact_Transactions] 



